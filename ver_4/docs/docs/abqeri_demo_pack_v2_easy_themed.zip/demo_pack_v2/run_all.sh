#!/usr/bin/env bash
echo stub
